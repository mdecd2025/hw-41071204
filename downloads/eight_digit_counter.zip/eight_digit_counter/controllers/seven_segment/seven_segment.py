from controller import Supervisor

class SevenSegmentController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor

        # Define the segments for each digit
        self.digit_segments = [
            [f"A0", f"B0", f"C0", f"D0", f"E0", f"F0", f"G0"],
            [f"A1", f"B1", f"C1", f"D1", f"E1", f"F1", f"G1"],
            [f"A2", f"B2", f"C2", f"D2", f"E2", f"F2", f"G2"],
            [f"A3", f"B3", f"C3", f"D3", f"E3", f"F3", f"G3"],
            [f"A4", f"B4", f"C4", f"D4", f"E4", f"F4", f"G4"],
            [f"A5", f"B5", f"C5", f"D5", f"E5", f"F5", f"G5"],
            [f"A6", f"B6", f"C6", f"D6", f"E6", f"F6", f"G6"],
            [f"A7", f"B7", f"C7", f"D7", f"E7", f"F7", f"G7"]
        ]


        # Segment patterns for digits 0-9
        self.segment_patterns = {
            0: [1, 1, 1, 1, 1, 1, 0],
            1: [0, 1, 1, 0, 0, 0, 0],
            2: [1, 1, 0, 1, 1, 0, 1],
            3: [1, 1, 1, 1, 0, 0, 1],
            4: [0, 1, 1, 0, 0, 1, 1],
            5: [1, 0, 1, 1, 0, 1, 1],
            6: [1, 0, 1, 1, 1, 1, 1],
            7: [1, 1, 1, 0, 0, 0, 0],
            8: [1, 1, 1, 1, 1, 1, 1],
            9: [1, 1, 1, 1, 0, 1, 1]
        }

        # Colors for on and off states
        self.color_on = color_on  # Bright green
        self.color_off = color_off  # Black

        # Retrieve material nodes for each segment
        self.segment_nodes = []
        for digit in self.digit_segments:
            digit_nodes = []
            for segment in digit:
                node = self.supervisor.getFromDef(segment)
                if node is None:
                    print(f"Error: Node with DEF name '{segment}' not found!")
                    exit()
                material_field = node.getField("appearance").getSFNode().getField("material").getSFNode().getField("diffuseColor")
                digit_nodes.append(material_field)
                print(f"Segment {segment} diffuseColor =", material_field.getSFVec3f())
            self.segment_nodes.append(digit_nodes)

    def set_digit(self, digit_index, value):
        """Set the digit at the given index (0 for units, 1 for tens, 2 for hundreds) to the given value (0-9)."""
        pattern = self.segment_patterns[value]
        for i, state in enumerate(pattern):
            color = self.color_on if state else self.color_off
            self.segment_nodes[digit_index][i].setSFVec3f(color)

    def display_number(self, number):
        """Display a number (0-99999999) using up to 8 7-segment displays."""
        if not (0 <= number <= 99999999):
            print("Error: Number out of range (must be 0-99999999)")
            return

        for i in range(8):  # 0 = 最右邊 (units), 7 = 最左邊 (ten-millions)
            digit_value = (number // (10 ** i)) % 10
            self.set_digit(i, digit_value)


# Main program
if __name__ == "__main__":
    # Create a Supervisor instance
    supervisor = Supervisor()

    # Define colors
    color_on = [0.0, 1.0, 0.0]  # Bright green
    color_off = [0.0, 0.0, 0.0]  # Black

    # Create an instance of the SevenSegmentController
    controller = SevenSegmentController(supervisor, color_on, color_off)

    # Run the simulation loop
    timestep = int(supervisor.getBasicTimeStep())
    while supervisor.step(timestep) != -1:
        try:
            # Get user input for the number to display
            number = 41071204
            controller.display_number(number)
        except ValueError:
            print("Invalid input. Please enter an integer between 0 and 999.")